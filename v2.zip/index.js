'use strict';
var Alexa = require('alexa-sdk');

var APP_ID = undefined; //OPTIONAL: replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";
var SKILL_NAME = 'Space Facts';

var unirest = require('unirest');

var theEvent;
var theContext;

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    theEvent = event;
    theContext = context;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var little_johny_jokes = [
	"And, Johnny? How did your school report turn out? asks mother. Come on mom, the most important thing is that I’m healthy!",
	"Little Johnny once bought his Granny a very fine toilet brush for her birthday. But when he went to visit her a few weeks later, there wasn’t a sign of it in the bathroom. Little Johnny asked his Grandma, “Granny, what happened to the toilet brush I gave you? Darling, I really didn’t like it. After all those years, I’ve gotten used to the toilet paper, and this new thing was just far too scratchy",
	"Little Johnny walks a cow through the village square. The mayor sees him and asks, “Hey Johnny, where are you going with the cow? I’m taking her to the bulls so she would get pregnant,” answers Johnny. The mayor is shocked, “Surely your father had better be doing that? Little Johnny thinks about it for a bit and shakes his head, Nah, I think it’s really best left with the bulls.",
	"Teacher: Why are you praying in class little Johnny? Little Johnny: My mom taught me to always pray before going to sleep.",
	"Little Johnny, why does your little sister cry? Because I helped her. But that is a good thing! What did you help her with? I helped her eat her gummy bears.",
	"Little Johnny asks the teacher, “Mrs Roberts, can I be punished for something I haven’t done? Mrs Roberts is shocked, “Of course not, Johnny, that would be very unfair! Little Johnny is relieved, OK Mrs Roberts, sorry, I haven’t done my homework.",
	"Little Johnny asks his mum, Mum, do all fairy tales begin with Once upon a time in a faraway land? No darling, says his mother, somewhat distressed, Sometimes, they can begin with I’ve got too much work in the office tonight, I’ll come home later.",
	"Little Johnny comes home and tells his daddy, Dad, tomorrow there’s a special Adults evening’ at school. Daddy is surprised, Really? Special? Yes, nods Johnny, it will be just you, the teacher, the headmaster and two police officers.",
	"After Sunday school, the teacher released the kids to go to church and reminded them, You all know to be very nice and quiet in the church. And why is that? Little Johnny offers, Miss, it’s so we wouldn’t wake all those people sleeping.",
	"Sunday school teacher asks Johnny, Come now, Little Johnny, tell me the truth, do you say your prayers before eating? Little Johnny smiles proudly, No Miss, there’s no need, my mom cooks really well.",
	"A teacher in Sunday school once asked Little Johnny, Johnny, do you believe in the Devil? No, said Little Johnny knowledgeably. It's just like with Santa Claus. I know it's really my dad.",
	"Miss Taylor the English teacher writes an incorrect sentence on the board: I didn’t had no fun for months. Then she faces the class and says, OK class, how should this be corrected? Little Johnny says, I think you should get yourself a better man!",
	"Mother, Johnny, if you keep being this naughty, you’ll get kids who will be very naughty to you! Johnny, Oh mom, you just betrayed yourself there, didn’t you?",
	"Little Johnny was sent back to bed for the tenth time that evening and his mommy is not amused. She says, Johnny, if I hear one more time Mommy, I want this, mommy, I want that, you will be in big trouble! I don’t want to hear the word mommy again tonight. Now off to bed you go! There’s a short pause, after which Johnny says hesitantly, Mrs Lambden, I want a glass of water, please.",
	"The teacher heard Little Johnny use some serious language and was shocked. Little Johnny, don’t you ever use language like that again, not near me, not ever. Where on earth did you learn that? I’ve got it from my dad, Miss, replies Johnny. Well, your daddy should be ashamed. I hope you don’t know what all that even means. Oh but I do, says Johnny. It means the car won’t start.",
	"The teacher was trying to put to use her recent psychology education. She asked everyone in her class, Alright, if any of you think you are stupid, please stand up! A few seconds pass by and then Little Johnny stands up. Startled, the teacher says, Oh, do you think you're stupid, Little Johnny? No, Miss, but I didn’t want to leave you standing all alone!"
];

var funny_sayings = [
	"My neighbors are listening to great music. Whether they like it or not.",
	"It is important to make breaks between individual exercises. I personally stick to breaks of about 3-4 years.",
	"I have no friends. Even the toilet cover attacks me from the back.",
	"Sometimes I drink water - just to surprise my liver.",
	"Hearing voices in your head is normal. Listening to them is quite common. Arguing with them – acceptable. It is only when you lose that argument that you get in real trouble.",
	"Of course I have a talent. I'm really good in bed. Sometimes I sleep more than 9 hours in one go.",
	"If I wanted to commit suicide, I would climb up to the height of your ego and jump down to your IQ level.",
	"According to my mirror I am pregnant. The father is Nutella.",
	"Sometimes it’s time to lay on the couch and do nothing at all for two years.",
	"Organized people are simply too lazy to search for stuff.",
	"My relationship is like an iPad. I don't have an iPad.",
	"I am nobody. Nobody is perfect. I am perfect.",
	"If I can still lie on the ground without having to hold myself, I'm not drunk.",
	"Do people talk about you behind your back? Simply fart.",
	"As long as cocoa beans grow on trees, chocolate is fruit to me.",
	"There are people who are a living proof that total brain failure does not always lead to physical death.",
	"Finally, the spring is here! I'm so thrilled I wet my plants.",
	"If you’re having a bad day, remember some adults wear braces.",
	"I’m aware that the voices in my head aren’t real. But their ideas are just awesome sometimes!",
	"Somebody said today that I'm lazy. I nearly answered him.",
	"I’m not lazy. I’m just naturally a very relaxed person.",
	"What can you say when it's already late and you really want to go home? Can you hear that? That's my pillow calling and it becomes really mean when I let it wait too long",
	"Laziness Rule Number 1: If an object falls under the bed, it is lost forever.",
	"My mood is currently swinging between an axe and gasoline.",
	"A housewife's battle. The household stares at me. I stare right back. Without breaking eye contact, I slide a piece of chocolate in my mouth. I won!",
	"He who wakes up early, yawns all day long.",
	"You can only be young once. But you can enjoy being infantile forever.",
	"Married women face a significantly lower risk of kidnapping, nobody can be certain that the ransom would actually be paid."
	"No thanks, I didn't fight my way to the top of the food pyramid to become a vegetarian.",
	"I am in touch with my motivation. I saw it going by this morning, waving at me and winking.",
	"I weighed myself today. It is clear I am too small for my weight."
];

var handlers = {
    'LaunchRequest': function () {
         this.emit(':ask', "Are you ready to have some fun? If you want a joke, just ask for it", SKILL_NAME)
    },
    'GetJoke': function () {
        var joke = funny_sayings[Math.floor(Math.random() * funny_sayings.length)];
         this.emit(':tell', joke, SKILL_NAME)
    },
    'AMAZON.HelpIntent': function () {
        var speechOutput = "I am here just to tell you jokes...";
        var reprompt = "What can I help you with?";
        this.emit(':tell', speechOutput, reprompt);
    },
    
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', 'Goodbye!');
    },
    
    'AMAZON.StopIntent': function () {
        this.emit(':tell', 'Goodbye!');
    }
};